# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  "/home/toweeelie/Work/FPGA_courses/myFPGA/homework_4/vitis/microblaze_led/platform/microblaze_0/standalone_microblaze_0/bsp/include/sleep.h"
  "/home/toweeelie/Work/FPGA_courses/myFPGA/homework_4/vitis/microblaze_led/platform/microblaze_0/standalone_microblaze_0/bsp/include/xiltimer.h"
  "/home/toweeelie/Work/FPGA_courses/myFPGA/homework_4/vitis/microblaze_led/platform/microblaze_0/standalone_microblaze_0/bsp/include/xtimer_config.h"
  "/home/toweeelie/Work/FPGA_courses/myFPGA/homework_4/vitis/microblaze_led/platform/microblaze_0/standalone_microblaze_0/bsp/lib/libxiltimer.a"
  )
endif()
