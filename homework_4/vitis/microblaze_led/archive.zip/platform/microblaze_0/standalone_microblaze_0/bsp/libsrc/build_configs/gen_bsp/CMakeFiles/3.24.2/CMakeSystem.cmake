set(CMAKE_HOST_SYSTEM "Linux-7.0.0-38-generic")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.0.0-38-generic")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/toweeelie/Work/FPGA_courses/myFPGA/homework_4/vitis/microblaze_led/platform/microblaze_0/standalone_microblaze_0/bsp/microblaze_toolchain.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "microblaze")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
